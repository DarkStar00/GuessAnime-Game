/*
  # Create messages table for chat feature

  1. New Tables
    - `messages`
      - `id` (bigint, primary key)
      - `created_at` (timestamp with time zone)
      - `username` (text)
      - `content` (text)

  2. Security
    - Enable RLS on messages table
    - Add policies for authenticated and anonymous users to read messages
    - Add policies for authenticated and anonymous users to insert messages
*/

CREATE TABLE IF NOT EXISTS messages (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  created_at timestamptz DEFAULT now(),
  username text NOT NULL,
  content text NOT NULL
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read messages
CREATE POLICY "Anyone can read messages"
  ON messages
  FOR SELECT
  TO public
  USING (true);

-- Allow anyone to insert messages
CREATE POLICY "Anyone can insert messages"
  ON messages
  FOR INSERT
  TO public
  WITH CHECK (true);