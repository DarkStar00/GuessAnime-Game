import React, { createContext, useContext, useState, useEffect } from 'react';
import { backgroundMusic } from '../data/audioData';

interface SettingsContextType {
  language: 'en' | 'ru';
  setLanguage: (lang: 'en' | 'ru') => void;
  showCompletedAnswers: boolean;
  setShowCompletedAnswers: (show: boolean) => void;
  musicEnabled: boolean;
  setMusicEnabled: (enabled: boolean) => void;
  currentTrack: number;
  nextTrack: () => void;
  previousTrack: () => void;
  volume: number;
  setVolume: (volume: number) => void;
  receiveMessages: boolean;
  setReceiveMessages: (receive: boolean) => void;
  showAnswerInput: boolean;
  setShowAnswerInput: (show: boolean) => void;
  username: string;
  setUsername: (username: string) => void;
  isChangeUsernameModalOpen: boolean;
  setIsChangeUsernameModalOpen: (isOpen: boolean) => void;
  imageQuality: 'low' | 'medium' | 'high';
  setImageQuality: (quality: 'low' | 'medium' | 'high') => void;
  audioQuality: 'low' | 'high';
  setAudioQuality: (quality: 'low' | 'high') => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<'en' | 'ru'>('en');
  const [showCompletedAnswers, setShowCompletedAnswers] = useState<boolean>(true);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(true);
  const [currentTrack, setCurrentTrack] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.5);
  const [receiveMessages, setReceiveMessages] = useState<boolean>(true);
  const [showAnswerInput, setShowAnswerInput] = useState<boolean>(true);
  const [username, setUsername] = useState<string>('');
  const [isChangeUsernameModalOpen, setIsChangeUsernameModalOpen] = useState<boolean>(false);
  const [imageQuality, setImageQuality] = useState<'low' | 'medium' | 'high'>('medium');
  const [audioQuality, setAudioQuality] = useState<'low' | 'high'>('high');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language');
    const savedShowAnswers = localStorage.getItem('showCompletedAnswers');
    const savedMusicEnabled = localStorage.getItem('musicEnabled');
    const savedCurrentTrack = localStorage.getItem('currentTrack');
    const savedVolume = localStorage.getItem('volume');
    const savedReceiveMessages = localStorage.getItem('receiveMessages');
    const savedShowAnswerInput = localStorage.getItem('showAnswerInput');
    const savedUsername = localStorage.getItem('username');
    const savedImageQuality = localStorage.getItem('imageQuality');
    const savedAudioQuality = localStorage.getItem('audioQuality');

    if (savedLanguage) {
      setLanguage(savedLanguage as 'en' | 'ru');
    }
    
    if (savedShowAnswers) {
      setShowCompletedAnswers(savedShowAnswers === 'true');
    }
    
    if (savedMusicEnabled) {
      setMusicEnabled(savedMusicEnabled === 'true');
    }
    
    if (savedCurrentTrack) {
      setCurrentTrack(parseInt(savedCurrentTrack));
    }

    if (savedVolume) {
      setVolume(parseFloat(savedVolume));
    }
    
    if (savedReceiveMessages) {
      setReceiveMessages(savedReceiveMessages === 'true');
    }
    
    if (savedShowAnswerInput) {
      setShowAnswerInput(savedShowAnswerInput === 'true');
    }

    if (savedUsername) {
      setUsername(savedUsername);
    }

    if (savedImageQuality) {
      setImageQuality(savedImageQuality as 'low' | 'medium' | 'high');
    }

    if (savedAudioQuality) {
      setAudioQuality(savedAudioQuality as 'low' | 'high');
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('language', language);
    localStorage.setItem('showCompletedAnswers', showCompletedAnswers.toString());
    localStorage.setItem('musicEnabled', musicEnabled.toString());
    localStorage.setItem('currentTrack', currentTrack.toString());
    localStorage.setItem('volume', volume.toString());
    localStorage.setItem('receiveMessages', receiveMessages.toString());
    localStorage.setItem('showAnswerInput', showAnswerInput.toString());
    localStorage.setItem('username', username);
    localStorage.setItem('imageQuality', imageQuality);
    localStorage.setItem('audioQuality', audioQuality);
  }, [
    language,
    showCompletedAnswers,
    musicEnabled,
    currentTrack,
    volume,
    receiveMessages,
    showAnswerInput,
    username,
    imageQuality,
    audioQuality
  ]);

  const nextTrack = () => {
    setCurrentTrack(prev => (prev + 1) % backgroundMusic.length);
  };

  const previousTrack = () => {
    setCurrentTrack(prev => (prev - 1 + backgroundMusic.length) % backgroundMusic.length);
  };

  return (
    <SettingsContext.Provider 
      value={{
        language,
        setLanguage,
        showCompletedAnswers,
        setShowCompletedAnswers,
        musicEnabled,
        setMusicEnabled,
        currentTrack,
        nextTrack,
        previousTrack,
        volume,
        setVolume,
        receiveMessages,
        setReceiveMessages,
        showAnswerInput,
        setShowAnswerInput,
        username,
        setUsername,
        isChangeUsernameModalOpen,
        setIsChangeUsernameModalOpen,
        imageQuality,
        setImageQuality,
        audioQuality,
        setAudioQuality
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};