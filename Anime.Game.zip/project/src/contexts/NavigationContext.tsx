import React, { createContext, useContext } from 'react';

interface NavigationContextType {
  navigateToGame: () => void;
}

export const NavigationContext = createContext<NavigationContextType | null>(null);

interface NavigationProviderProps {
  children: React.ReactNode;
  onNavigateToGame: () => void;
}

export const NavigationProvider: React.FC<NavigationProviderProps> = ({ children, onNavigateToGame }) => {
  return (
    <NavigationContext.Provider value={{ navigateToGame: onNavigateToGame }}>
      {children}
    </NavigationContext.Provider>
  );
};