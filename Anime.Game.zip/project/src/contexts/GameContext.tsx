import React, { createContext, useContext, useState, useEffect } from 'react';
import { allLevels, TOTAL_LEVELS, AnimeLevel } from '../data/animeData';

interface GameContextType {
  currentLevel: number;
  setCurrentLevel: (level: number) => void;
  completedLevels: number[];
  checkAnswer: (answer: string) => boolean;
  getCurrentLevelData: () => AnimeLevel;
  completeLevel: (levelId: number) => void;
  resetProgress: () => void;
  isLevelCompleted: (levelId: number) => boolean;
  totalCompleted: number;
  showHint: boolean;
  setShowHint: (show: boolean) => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);
  const [showHint, setShowHint] = useState<boolean>(false);
  
  // Load saved progress from localStorage
  useEffect(() => {
    const savedLevel = localStorage.getItem('currentLevel');
    const savedCompletedLevels = localStorage.getItem('completedLevels');
    
    if (savedLevel) {
      setCurrentLevel(parseInt(savedLevel));
    }
    
    if (savedCompletedLevels) {
      setCompletedLevels(JSON.parse(savedCompletedLevels));
    }
  }, []);
  
  // Save progress to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('currentLevel', currentLevel.toString());
    localStorage.setItem('completedLevels', JSON.stringify(completedLevels));
  }, [currentLevel, completedLevels]);
  
  const getCurrentLevelData = (): AnimeLevel => {
    return allLevels.find(level => level.id === currentLevel) || allLevels[0];
  };
  
  const checkAnswer = (answer: string): boolean => {
    const currentData = getCurrentLevelData();
    return currentData.answer.toLowerCase() === answer.toLowerCase();
  };
  
  const completeLevel = (levelId: number) => {
    if (!completedLevels.includes(levelId)) {
      setCompletedLevels(prev => [...prev, levelId].sort((a, b) => a - b));
    }
  };
  
  const resetProgress = () => {
    setCompletedLevels([]);
    setCurrentLevel(1);
    localStorage.removeItem('completedLevels');
    localStorage.setItem('currentLevel', '1');
  };
  
  const isLevelCompleted = (levelId: number): boolean => {
    return completedLevels.includes(levelId);
  };
  
  return (
    <GameContext.Provider 
      value={{
        currentLevel,
        setCurrentLevel,
        completedLevels,
        checkAnswer,
        getCurrentLevelData,
        completeLevel,
        resetProgress,
        isLevelCompleted,
        totalCompleted: completedLevels.length,
        showHint,
        setShowHint
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = (): GameContextType => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};