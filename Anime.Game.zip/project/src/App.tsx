import React, { useState, useRef, useEffect } from 'react';
import Navigation from './components/Navigation';
import GameScreen from './components/GameScreen';
import LevelsScreen from './components/LevelsScreen';
import SettingsScreen from './components/SettingsScreen';
import ChatBox from './components/ChatBox';
import { GameProvider } from './contexts/GameContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { NavigationProvider } from './contexts/NavigationContext';
import { backgroundMusic } from './data/audioData';
import { useSettings } from './contexts/SettingsContext';

function AppContent() {
  const [activeTab, setActiveTab] = useState<'game' | 'levels' | 'settings'>('game');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { 
    musicEnabled, 
    volume, 
    currentTrack, 
    nextTrack,
    audioQuality 
  } = useSettings();

  // Handle track ending and auto-play next
  useEffect(() => {
    if (audioRef.current) {
      const audio = audioRef.current;
      
      const handleEnded = () => {
        nextTrack(); // This will trigger the track change
      };

      audio.addEventListener('ended', handleEnded);
      
      return () => {
        audio.removeEventListener('ended', handleEnded);
      };
    }
  }, [nextTrack]);

  // Handle volume and play/pause
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      
      if (musicEnabled) {
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            console.log('Auto-play prevented:', error);
          });
        }
      } else {
        audioRef.current.pause();
      }
    }
  }, [musicEnabled, volume]);

  // Handle track changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.load();
      if (musicEnabled) {
        const playPromise = audioRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            console.log('Auto-play prevented:', error);
          });
        }
      }
    }
  }, [currentTrack, musicEnabled, audioQuality]);

  const handleNavigateToGame = () => {
    setActiveTab('game');
  };

  return (
    <NavigationProvider onNavigateToGame={handleNavigateToGame}>
      <div className="min-h-screen bg-gray-800 text-white flex flex-col">
        <audio
          ref={audioRef}
          src={backgroundMusic[currentTrack]?.url || ''}
          preload="auto"
          style={{ display: 'none' }}
        />
        
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        
        <ChatBox />
        
        <div className="flex-1 overflow-auto">
          {activeTab === 'game' && <GameScreen />}
          {activeTab === 'levels' && <LevelsScreen />}
          {activeTab === 'settings' && <SettingsScreen />}
        </div>
      </div>
    </NavigationProvider>
  );
}

function App() {
  return (
    <SettingsProvider>
      <GameProvider>
        <AppContent />
      </GameProvider>
    </SettingsProvider>
  );
}

export default App;