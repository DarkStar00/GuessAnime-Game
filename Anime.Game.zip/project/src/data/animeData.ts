import { useSettings } from '../contexts/SettingsContext';

export interface AnimeLevel {
  id: number;
  imageUrl: string;
  answer: string;
  hint?: string;
}

export const animeData: AnimeLevel[] = [
  {
    id: 1,
    imageUrl: "/assets/images/level1.jpg",
    answer: "Naruto",
    hint: "A ninja with a nine-tailed fox"
  },
  // ... rest of the animeData array remains unchanged
];

const getImageQualityParams = (quality: 'low' | 'medium' | 'high') => {
  switch (quality) {
    case 'low':
      return 'auto=compress&w=400&q=70';
    case 'medium':
      return 'auto=compress&w=800&q=80';
    case 'high':
      return 'auto=compress&w=1200&q=90';
    default:
      return 'auto=compress&w=800&q=80';
  }
};

export const generateLevels = (count: number): AnimeLevel[] => {
  const result: AnimeLevel[] = [];
  
  // First, add all the predefined levels
  result.push(...animeData);
  
  // Then generate additional levels if needed
  for (let i = result.length + 1; i <= count; i++) {
    result.push({
      id: i,
      imageUrl: `https://images.pexels.com/photos/6985132/pexels-photo-6985132.jpeg?${getImageQualityParams('medium')}`,
      answer: `Anime ${i}`,
      hint: `This is a placeholder for level ${i}`
    });
  }
  
  return result;
};

export const TOTAL_LEVELS = 51;
export const allLevels = generateLevels(TOTAL_LEVELS);