export interface AudioTrack {
  id: number;
  name: string;
  url: string;
}

export const backgroundMusic: AudioTrack[] = [
  {
    id: 1,
    name: "Anime Theme 1",
    url: "/assets/audio/track01.mp3"
  },
  {
    id: 2,
    name: "Anime Theme 2",
    url: "/assets/audio/track02.mp3"
  },
  {
    id: 3,
    name: "Anime Theme 3",
    url: "/assets/audio/track03.mp3"
  }
];