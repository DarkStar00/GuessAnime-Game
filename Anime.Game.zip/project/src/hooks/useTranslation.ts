import { useSettings } from '../contexts/SettingsContext';

type TranslationKey = 
  | 'levels'
  | 'game'
  | 'settings'
  | 'level'
  | 'enterAnimeName'
  | 'hint'
  | 'animeRadio'
  | 'showCompletedAnswers'
  | 'receiveMessages'
  | 'showAnswerInput'
  | 'reportBug'
  | 'suggestAnime'
  | 'vkGroup'
  | 'authors'
  | 'fixImages'
  | 'changeNickname'
  | 'resetProgress'
  | 'version'
  | 'confirmReset'
  | 'audioQuality'
  | 'imageQuality'
  | 'low'
  | 'medium'
  | 'high';

const translations: Record<'en' | 'ru', Record<TranslationKey, string>> = {
  en: {
    levels: 'Levels',
    game: 'Game',
    settings: 'Settings',
    level: 'Level',
    enterAnimeName: 'Enter anime name...',
    hint: 'Hint',
    animeRadio: 'Anime Radio',
    showCompletedAnswers: 'Show completed answers',
    receiveMessages: 'Receive developer messages',
    showAnswerInput: 'Show answer input dialog',
    reportBug: 'Report a bug',
    suggestAnime: 'Suggest anime',
    vkGroup: 'VK Group',
    authors: 'Authors',
    fixImages: 'Fix images',
    changeNickname: 'Change nickname',
    resetProgress: 'Reset progress',
    version: 'Version',
    confirmReset: 'Are you sure you want to reset your progress? This cannot be undone.',
    audioQuality: 'Audio Quality',
    imageQuality: 'Image Quality',
    low: 'Low',
    medium: 'Medium',
    high: 'High'
  },
  ru: {
    levels: 'Уровни',
    game: 'Игра',
    settings: 'Настройки',
    level: 'Уровень',
    enterAnimeName: 'Введите название аниме...',
    hint: 'Подсказка',
    animeRadio: 'Радио Anison.fm',
    showCompletedAnswers: 'Показывать названия у угаданных уровней',
    receiveMessages: 'Получать сообщения от разработчика',
    showAnswerInput: 'Открывать окно с отправкой своего варианта ответа',
    reportBug: 'Пожаловаться на все, ну, или не на все',
    suggestAnime: 'Предложить аниме',
    vkGroup: 'Группа в ВК',
    authors: 'Авторы',
    fixImages: 'Починить картинки',
    changeNickname: 'Сменить ник',
    resetProgress: 'Стереть прогресс',
    version: 'Версия',
    confirmReset: 'Вы уверены, что хотите стереть свой прогресс? Это действие нельзя отменить.',
    audioQuality: 'Качество аудио',
    imageQuality: 'Качество изображений',
    low: 'Низкое',
    medium: 'Среднее',
    high: 'Высокое'
  }
};

export const useTranslation = () => {
  const { language } = useSettings();
  
  const t = (key: TranslationKey): string => {
    return translations[language][key] || key;
  };
  
  return { t };
};