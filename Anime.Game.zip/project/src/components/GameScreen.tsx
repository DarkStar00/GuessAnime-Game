import React, { useState, useEffect } from 'react';
import { HelpCircle, ChevronLeft, ChevronRight, Send } from 'lucide-react';
import { useGame } from '../contexts/GameContext';
import { useSettings } from '../contexts/SettingsContext';
import { useTranslation } from '../hooks/useTranslation';
import { TOTAL_LEVELS } from '../data/animeData';

const GameScreen: React.FC = () => {
  const { 
    currentLevel, 
    setCurrentLevel, 
    checkAnswer, 
    getCurrentLevelData,
    isLevelCompleted,
    showHint,
    setShowHint,
    completeLevel
  } = useGame();
  
  const { showCompletedAnswers } = useSettings();
  const { t } = useTranslation();
  
  const [answer, setAnswer] = useState<string>('');
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [shake, setShake] = useState<boolean>(false);
  
  const currentLevelData = getCurrentLevelData();
  const levelCompleted = isLevelCompleted(currentLevel);
  
  // Reset state when level changes
  useEffect(() => {
    setAnswer('');
    setIsCorrect(null);
    setShowHint(false);
  }, [currentLevel, setShowHint]);
  
  const handlePrevLevel = () => {
    if (currentLevel > 1) {
      setCurrentLevel(currentLevel - 1);
    }
  };
  
  const handleNextLevel = () => {
    if (currentLevel < TOTAL_LEVELS) {
      setCurrentLevel(currentLevel + 1);
    }
  };
  
  const handleAnswerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAnswer(e.target.value);
    if (isCorrect !== null) {
      setIsCorrect(null);
    }
  };
  
  const handleSubmitAnswer = (e?: React.FormEvent) => {
    e?.preventDefault();
    
    if (!answer.trim()) return;
    
    const correct = checkAnswer(answer.trim());
    setIsCorrect(correct);
    
    if (correct) {
      completeLevel(currentLevel);
      // Keep the answer visible
      setAnswer(currentLevelData.answer);
    } else {
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };
  
  const toggleHint = () => {
    setShowHint(!showHint);
  };
  
  const shouldShowAnswer = (levelCompleted || isCorrect) && showCompletedAnswers;
  
  return (
    <div className="flex flex-col items-center p-4 max-w-md mx-auto">
      <div className="w-full aspect-square overflow-hidden rounded-lg mb-4 border-4 border-gray-700">
        <img 
          src={currentLevelData.imageUrl} 
          alt={`Anime level ${currentLevel}`}
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Level indicator and answer field */}
      <div className="w-full mb-6">
        <div 
          className={`w-full border-2 ${shouldShowAnswer ? 'border-green-500 bg-green-500 text-white' : 'border-orange-500'} 
            rounded-md px-4 py-3 text-center mb-2 text-xl font-bold transition-colors duration-300`}
        >
          {shouldShowAnswer ? currentLevelData.answer : `${t('level')} ${currentLevel}`}
        </div>
        
        {!shouldShowAnswer && (
          <form onSubmit={handleSubmitAnswer} className="w-full flex gap-2">
            <input
              type="text"
              value={answer}
              onChange={handleAnswerChange}
              placeholder={t('enterAnimeName')}
              className={`flex-1 border-2 border-gray-400 rounded-md px-4 py-2 focus:outline-none focus:border-orange-500 text-black
                ${shake ? 'animate-shake' : ''}
                ${isCorrect === true ? 'bg-green-100 border-green-500' : ''}
                ${isCorrect === false ? 'bg-red-100 border-red-500' : ''}`}
              autoFocus
            />
            <button
              type="submit"
              className="bg-orange-400 hover:bg-orange-500 text-white px-4 rounded-md transition-colors duration-300 flex items-center justify-center"
            >
              <Send size={24} />
            </button>
          </form>
        )}
      </div>
      
      {/* Navigation buttons */}
      <div className="flex justify-between w-full mb-4">
        <button 
          onClick={handlePrevLevel}
          className={`bg-orange-400 hover:bg-orange-500 text-white py-4 px-10 rounded-md transition-colors duration-300 flex items-center justify-center
            ${currentLevel === 1 ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={currentLevel === 1}
        >
          <ChevronLeft size={32} />
        </button>
        
        <button 
          onClick={toggleHint}
          className="bg-green-400 hover:bg-green-500 text-white py-4 px-10 rounded-md transition-colors duration-300 flex items-center justify-center"
        >
          <HelpCircle size={32} />
        </button>
        
        <button 
          onClick={handleNextLevel}
          className={`bg-orange-400 hover:bg-orange-500 text-white py-4 px-10 rounded-md transition-colors duration-300 flex items-center justify-center
            ${currentLevel === TOTAL_LEVELS ? 'opacity-50 cursor-not-allowed' : ''}`}
          disabled={currentLevel === TOTAL_LEVELS}
        >
          <ChevronRight size={32} />
        </button>
      </div>
      
      {/* Hint */}
      {showHint && currentLevelData.hint && (
        <div className="bg-yellow-100 border-2 border-yellow-300 rounded-md p-4 w-full mb-4 animate-fadeIn">
          <p className="text-yellow-800"><strong>{t('hint')}:</strong> {currentLevelData.hint}</p>
        </div>
      )}
    </div>
  );
};

export default GameScreen;