import React from 'react';

interface ToggleProps {
  checked: boolean;
  onChange: () => void;
}

const Toggle: React.FC<ToggleProps> = ({ checked, onChange }) => {
  return (
    <button
      type="button"
      className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors duration-300 focus:outline-none
        ${checked ? 'bg-green-500' : 'bg-gray-600'}`}
      onClick={onChange}
    >
      <span
        className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform duration-300
          ${checked ? 'translate-x-7' : 'translate-x-1'}`}
      />
    </button>
  );
};

export default Toggle;