import React from 'react';
import { useTranslation } from '../hooks/useTranslation';

interface NavigationProps {
  activeTab: 'game' | 'levels' | 'settings';
  onTabChange: (tab: 'game' | 'levels' | 'settings') => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const { t } = useTranslation();
  
  return (
    <nav className="bg-gray-800 text-white py-4 px-2 flex justify-between items-center">
      <button 
        className={`text-2xl font-bold transition-colors duration-300 ${activeTab === 'levels' ? 'text-green-400' : 'text-orange-400 hover:text-green-400'}`}
        onClick={() => onTabChange('levels')}
      >
        {t('levels')}
      </button>
      
      <button 
        className={`text-2xl font-bold transition-colors duration-300 ${activeTab === 'game' ? 'text-green-400' : 'text-orange-400 hover:text-green-400'}`}
        onClick={() => onTabChange('game')}
      >
        {t('game')}
      </button>
      
      <button 
        className={`text-2xl font-bold transition-colors duration-300 ${activeTab === 'settings' ? 'text-green-400' : 'text-orange-400 hover:text-green-400'}`}
        onClick={() => onTabChange('settings')}
      >
        {t('settings')}
      </button>
    </nav>
  );
};

export default Navigation;