import React, { useState } from 'react';
import { Music, Settings as SettingsIcon, Volume2, Image } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { useGame } from '../contexts/GameContext';
import { useTranslation } from '../hooks/useTranslation';
import Toggle from './Toggle';

const SettingsScreen: React.FC = () => {
  const { 
    language, 
    setLanguage,
    showCompletedAnswers, 
    setShowCompletedAnswers,
    musicEnabled,
    setMusicEnabled,
    volume,
    setVolume,
    receiveMessages,
    setReceiveMessages,
    showAnswerInput,
    setShowAnswerInput,
    username,
    setUsername,
    isChangeUsernameModalOpen,
    setIsChangeUsernameModalOpen,
    imageQuality,
    setImageQuality,
    audioQuality,
    setAudioQuality
  } = useSettings();
  
  const { resetProgress } = useGame();
  const { t } = useTranslation();
  const [tempUsername, setTempUsername] = useState(username);
  const [showAuthors, setShowAuthors] = useState(false);

  const handleResetProgress = () => {
    if (window.confirm(t('confirmReset'))) {
      resetProgress();
    }
  };
  
  const handleLanguageChange = () => {
    setLanguage(language === 'en' ? 'ru' : 'en');
  };

  const handleUsernameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempUsername.trim()) {
      setUsername(tempUsername.trim());
      setIsChangeUsernameModalOpen(false);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(parseFloat(e.target.value));
  };

  const handleShowAuthors = () => {
    setShowAuthors(true);
  };
  
  return (
    <div className="p-4 max-w-md mx-auto">
      {/* Music settings */}
      <div className="mb-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Music className="text-green-400 mr-2" size={24} />
            <span className="text-green-400 text-lg">{t('animeRadio')}</span>
          </div>
          <div className="flex items-center">
            <SettingsIcon className="text-orange-400 mr-2" size={24} />
            <Toggle checked={musicEnabled} onChange={() => setMusicEnabled(!musicEnabled)} />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Volume2 className="text-green-400" size={20} />
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={handleVolumeChange}
            className="flex-1 h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <div className="flex items-center justify-between">
          <span className="text-green-400">{t('audioQuality')}</span>
          <select
            value={audioQuality}
            onChange={(e) => setAudioQuality(e.target.value as 'low' | 'high')}
            className="bg-gray-700 text-white rounded-md px-3 py-1"
          >
            <option value="low">{t('low')}</option>
            <option value="high">{t('high')}</option>
          </select>
        </div>
      </div>

      {/* Image quality settings */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Image className="text-green-400 mr-2" size={24} />
            <span className="text-green-400 text-lg">{t('imageQuality')}</span>
          </div>
          <select
            value={imageQuality}
            onChange={(e) => setImageQuality(e.target.value as 'low' | 'medium' | 'high')}
            className="bg-gray-700 text-white rounded-md px-3 py-1"
          >
            <option value="low">{t('low')}</option>
            <option value="medium">{t('medium')}</option>
            <option value="high">{t('high')}</option>
          </select>
        </div>
      </div>
      
      {/* Show completed answers */}
      <div className="mb-6 flex items-center justify-between">
        <span className="text-green-400 text-lg">{t('showCompletedAnswers')}</span>
        <Toggle checked={showCompletedAnswers} onChange={() => setShowCompletedAnswers(!showCompletedAnswers)} />
      </div>
      
      {/* Receive messages */}
      <div className="mb-6 flex items-center justify-between">
        <span className="text-green-400 text-lg">{t('receiveMessages')}</span>
        <Toggle checked={receiveMessages} onChange={() => setReceiveMessages(!receiveMessages)} />
      </div>
      
      {/* Show answer input */}
      <div className="mb-6 flex items-center justify-between">
        <span className="text-green-400 text-lg">{t('showAnswerInput')}</span>
        <Toggle checked={showAnswerInput} onChange={() => setShowAnswerInput(!showAnswerInput)} />
      </div>
      
      {/* Additional buttons */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <button className="bg-green-400 hover:bg-green-500 text-white py-2 px-4 rounded-md transition-colors duration-300">
          {t('reportBug')}
        </button>
        <button className="bg-green-400 hover:bg-green-500 text-white py-2 px-4 rounded-md transition-colors duration-300">
          {t('suggestAnime')}
        </button>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-10">
        <a 
          href="https://vk.com" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-green-400 hover:bg-green-500 text-white py-2 px-4 rounded-md transition-colors duration-300 text-center"
        >
          {t('vkGroup')}
        </a>
        <button 
          onClick={handleShowAuthors}
          className="bg-green-400 hover:bg-green-500 text-white py-2 px-4 rounded-md transition-colors duration-300"
        >
          {t('authors')}
        </button>
      </div>
      
      {/* Bottom buttons */}
      <div className="grid grid-cols-3 gap-4 mb-10">
        <button className="bg-green-400 hover:bg-green-500 text-white py-2 px-4 rounded-md transition-colors duration-300 text-sm">
          {t('fixImages')}
        </button>
        <button 
          onClick={() => setIsChangeUsernameModalOpen(true)}
          className="bg-green-400 hover:bg-green-500 text-white py-2 px-4 rounded-md transition-colors duration-300 text-sm"
        >
          {t('changeNickname')}
        </button>
        <button 
          onClick={handleResetProgress}
          className="bg-green-400 hover:bg-red-500 text-white py-2 px-4 rounded-md transition-colors duration-300 text-sm"
        >
          {t('resetProgress')}
        </button>
      </div>
      
      {/* Language and version */}
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <button onClick={handleLanguageChange} className="border-2 border-orange-400 rounded-md p-1">
            {language === 'en' ? (
              <img src="https://flagsapi.com/US/flat/64.png" alt="English" className="w-10 h-6" />
            ) : (
              <img src="https://flagsapi.com/RU/flat/64.png" alt="Russian" className="w-10 h-6" />
            )}
          </button>
        </div>
        <div className="text-orange-400">
          {t('version')} 1.0.0
        </div>
      </div>

      {/* Username Modal */}
      {isChangeUsernameModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl w-96">
            <h3 className="text-xl font-bold text-white mb-4">
              {language === 'en' ? 'Change Username' : 'Изменить никнейм'}
            </h3>
            <form onSubmit={handleUsernameSubmit} className="space-y-4">
              <input
                type="text"
                value={tempUsername}
                onChange={(e) => setTempUsername(e.target.value)}
                placeholder={language === 'en' ? 'Enter username...' : 'Введите никнейм...'}
                className="w-full px-3 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsChangeUsernameModalOpen(false)}
                  className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
                >
                  {language === 'en' ? 'Cancel' : 'Отмена'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors"
                >
                  {language === 'en' ? 'Save' : 'Сохранить'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Authors Modal */}
      {showAuthors && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl w-96">
            <h3 className="text-xl font-bold text-white mb-4">
              {language === 'en' ? 'Authors' : 'Авторы'}
            </h3>
            <div className="space-y-2 text-white mb-4">
              <p>Создатель:</p>
              <p>Фасоль</p>
              <p>//////////////////////////////////////////////////////</p>
              <p>Сразработчик:</p>
              <p>Ноунейм</p>
            </div>
            <div className="flex justify-end">
              <button
                onClick={() => setShowAuthors(false)}
                className="px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors"
              >
                {language === 'en' ? 'Close' : 'Закрыть'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsScreen;