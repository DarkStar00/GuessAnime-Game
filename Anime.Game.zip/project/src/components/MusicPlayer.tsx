import React, { useRef, useEffect } from 'react';
import { Volume2, SkipBack, SkipForward, Play, Pause } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { backgroundMusic } from '../data/audioData';

const MusicPlayer: React.FC = () => {
  const { 
    musicEnabled, 
    setMusicEnabled,
    currentTrack,
    nextTrack,
    previousTrack,
    volume,
    setVolume,
    audioQuality
  } = useSettings();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      
      if (musicEnabled) {
        const playPromise = audioRef.current.play();
        
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            console.log('Auto-play prevented:', error);
          });
        }
      } else {
        audioRef.current.pause();
      }
    }
  }, [musicEnabled, currentTrack, volume]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.load();
    }
  }, [audioQuality, currentTrack]);

  const handleAudioEnded = () => {
    nextTrack();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
  };

  return (
    <>
      <audio
        ref={audioRef}
        src={backgroundMusic[currentTrack]?.url || ''}
        loop={false}
        preload="auto"
        onEnded={handleAudioEnded}
        style={{ display: 'none' }}
      />
      
      <div className="fixed bottom-20 left-4 bg-gray-800 p-4 rounded-lg shadow-lg">
        <div className="flex items-center gap-4">
          <button
            onClick={previousTrack}
            className="text-white hover:text-orange-400 transition-colors"
          >
            <SkipBack size={24} />
          </button>
          
          <button
            onClick={() => setMusicEnabled(!musicEnabled)}
            className="text-white hover:text-orange-400 transition-colors"
          >
            {musicEnabled ? <Pause size={24} /> : <Play size={24} />}
          </button>
          
          <button
            onClick={nextTrack}
            className="text-white hover:text-orange-400 transition-colors"
          >
            <SkipForward size={24} />
          </button>
          
          <div className="flex items-center gap-2">
            <Volume2 size={20} className="text-white" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={handleVolumeChange}
              className="w-24 h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default MusicPlayer;