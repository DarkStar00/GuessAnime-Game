import React, { useState, useEffect, useRef } from 'react';
import { format } from 'date-fns';
import { MessageSquare, Send } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { supabase, isSupabaseConfigured } from '../lib/supabaseClient';

interface Message {
  id: number;
  created_at: string;
  username: string;
  content: string;
}

const ChatBox: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { language, username } = useSettings();
  const channelRef = useRef<ReturnType<typeof supabase.channel>>();
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [isInitialScroll, setIsInitialScroll] = useState(true);

  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    if (isOpen && isInitialScroll) {
      scrollToBottom();
      setIsInitialScroll(false);
    }
  }, [isOpen, messages, isInitialScroll]);

  useEffect(() => {
    if (!isSupabaseConfigured) return;

    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error fetching messages:', error);
        return;
      }

      setMessages(data.reverse());
    };

    fetchMessages();

    // Set up real-time subscription
    channelRef.current = supabase
      .channel('messages_channel')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        payload => {
          setMessages(current => [...current, payload.new as Message]);
          if (isOpen) {
            setTimeout(scrollToBottom, 100);
          }
        }
      )
      .subscribe();

    // Cleanup subscription
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
    };
  }, [isOpen]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !username || !isSupabaseConfigured) return;

    const { error } = await supabase
      .from('messages')
      .insert([
        {
          username: username,
          content: newMessage.trim()
        }
      ]);

    if (error) {
      console.error('Error sending message:', error);
      return;
    }

    setNewMessage('');
  };

  if (!isSupabaseConfigured || !username) {
    return null;
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 bg-orange-500 text-white p-3 rounded-full shadow-lg hover:bg-orange-600 transition-colors"
      >
        <MessageSquare size={24} />
      </button>

      {isOpen && (
        <div className="fixed bottom-20 right-4 bg-gray-800 rounded-lg shadow-lg w-80 flex flex-col max-h-[600px]">
          <div className="flex justify-between items-center p-3 border-b border-gray-700">
            <h3 className="text-white font-semibold">
              {language === 'en' ? 'Chat' : 'Чат'}
            </h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              ✕
            </button>
          </div>

          <div 
            ref={chatContainerRef}
            className="flex-1 overflow-y-auto p-3 space-y-3"
          >
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex flex-col ${
                  message.username === username ? 'items-end' : 'items-start'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm text-gray-400">
                    {format(new Date(message.created_at), 'HH:mm:ss')}
                  </span>
                  <span className={`font-semibold ${
                    message.username === username ? 'text-orange-400' : 'text-green-400'
                  }`}>
                    {message.username}
                  </span>
                </div>
                <div className={`rounded-lg px-3 py-2 max-w-[80%] ${
                  message.username === username
                    ? 'bg-orange-500 text-white'
                    : 'bg-gray-700 text-white'
                }`}>
                  {message.content}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-700">
            <div className="flex gap-2">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={language === 'en' ? 'Type a message...' : 'Введите сообщение...'}
                className="flex-1 px-3 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <button
                type="submit"
                className="bg-orange-500 text-white p-2 rounded-md hover:bg-orange-600 transition-colors"
                disabled={!username}
              >
                <Send size={20} />
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
};

export default ChatBox;