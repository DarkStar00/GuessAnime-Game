import React from 'react';
import { useGame } from '../contexts/GameContext';
import { useTranslation } from '../hooks/useTranslation';
import { TOTAL_LEVELS } from '../data/animeData';
import { useNavigate } from '../hooks/useNavigate';

const LevelsScreen: React.FC = () => {
  const { currentLevel, setCurrentLevel, completedLevels, totalCompleted, isLevelCompleted } = useGame();
  const { t } = useTranslation();
  const { navigateToGame } = useNavigate();
  
  const renderProgressBar = () => {
    const percentComplete = (totalCompleted / TOTAL_LEVELS) * 100;
    
    return (
      <div className="relative w-full h-8 bg-gray-700 rounded-full overflow-hidden border-2 border-orange-400 mb-6">
        <div 
          className="absolute top-0 left-0 h-full bg-green-500 transition-all duration-500 ease-out"
          style={{ width: `${percentComplete}%` }}
        />
        <div className="absolute top-0 left-0 w-full h-full flex items-center justify-center">
          <div className="flex items-center space-x-1">
            <span className="text-xl font-bold text-white drop-shadow-lg transition-all duration-300">
              {totalCompleted}
            </span>
            <span className="text-xl font-bold text-white drop-shadow-lg">/</span>
            <span className="text-xl font-bold text-white drop-shadow-lg">
              {TOTAL_LEVELS}
            </span>
          </div>
        </div>
      </div>
    );
  };
  
  const handleLevelClick = (level: number) => {
    setCurrentLevel(level);
    navigateToGame();
  };
  
  // Create array of levels for rendering
  const levelsArray = Array.from({ length: TOTAL_LEVELS }, (_, i) => i + 1);
  
  return (
    <div className="p-4 max-w-md mx-auto">
      {renderProgressBar()}
      
      <div className="grid grid-cols-4 gap-4">
        {levelsArray.map(level => (
          <button
            key={level}
            onClick={() => handleLevelClick(level)}
            className={`
              w-full aspect-square rounded-md flex items-center justify-center text-2xl font-bold
              transition-all duration-300 transform hover:scale-105
              ${isLevelCompleted(level) ? 'bg-green-500 text-white' : 'bg-orange-400 text-white'}
              ${currentLevel === level ? 'ring-4 ring-white scale-105' : ''}
            `}
          >
            {level}
          </button>
        ))}
      </div>
    </div>
  );
};

export default LevelsScreen;