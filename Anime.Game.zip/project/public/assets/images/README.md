# Level Images

Place your level images in this folder. Each image should be named according to its level number, for example:
- level1.jpg
- level2.jpg
- level3.jpg

Image requirements:
- Recommended size: 800x800 pixels
- Supported formats: JPG, PNG
- Maximum file size: 2MB per image

To use these images in the game:
1. Place your images in this folder
2. Update the `imageUrl` in `src/data/animeData.ts` to point to these local images:

```typescript
{
  id: 1,
  imageUrl: "/assets/images/level1.jpg",
  answer: "Naruto",
  hint: "A ninja with a nine-tailed fox"
}
```