# Background Music

Place your background music tracks in this folder. Each track should be named descriptively, for example:
- track1.mp3
- track2.mp3
- track3.mp3

Audio requirements:
- Format: MP3
- Recommended bitrate: 128-192 kbps
- Maximum file size: 5MB per track

To use these audio tracks in the game:
1. Place your audio files in this folder
2. Update the `url` in `src/data/audioData.ts` to point to these local audio files:

```typescript
{
  id: 1,
  name: "Anime Theme 1",
  url: "/assets/audio/track1.mp3"
}
```